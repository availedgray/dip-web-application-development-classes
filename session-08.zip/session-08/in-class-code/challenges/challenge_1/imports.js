//Log the userObject out to the console using the file in the user folder
console.log(userObject);
