**Each file contains one bug related to JavaScript concepts:**

- arrow functions
- objects
- arrays and
- array methods
- destructuring
- template literals
- ternary operators
- ES modules

**Note:** Use the manually create my-react-app top run the code

1. Change the name of the challenge file to **UserObject.js** & move the files to the my-react-app manual template
2. `run npm install` to create the project
3. `npm start` and then open up to your React Developer Tools
4. Identify and fix the bugs in each file
5. Run the corrected code to ensure it works as expected with userObject
